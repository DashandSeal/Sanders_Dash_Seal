SANDERS FAMILY OF COMPANIES - HAPPY NEW YEAR 2027
EXECUTIVE HALLWAY POSTER

PRINT: 24 x 18 inches, 300 DPI; landscape orientation.
The JPG and PDF have identical full-resolution 7200 x 5400 artwork.
Keep the entire outer gold frame visible when framing (do not crop).
Set your print shop to print at actual size, not Fit to Page.
Ask the print shop to confirm paper stock, RGB/CMYK conversion and their recommended finish.

AUTHENTIC SOURCE ASSETS:
- Official headquarters seal: Sanders_Corporate_Headquarters_Official_Seal_EST_1996.png (composited without re-creating the emblem)
- 10 original family photograph files: 0a51dad9-51f6-43a3-bd6e-4033280e47a7-1_all_117.png, 0a51dad9-51f6-43a3-bd6e-4033280e47a7-1_all_1899.jpg, 0a51dad9-51f6-43a3-bd6e-4033280e47a7-1_all_1962.jpg, 0a51dad9-51f6-43a3-bd6e-4033280e47a7-1_all_2136.jpg, 0a51dad9-51f6-43a3-bd6e-4033280e47a7-1_all_620.jpg, 0a51dad9-51f6-43a3-bd6e-4033280e47a7-1_all_740.jpg, 0a51dad9-51f6-43a3-bd6e-4033280e47a7-1_all_761.jpg, 0a51dad9-51f6-43a3-bd6e-4033280e47a7-1_all_768.jpg, 0a51dad9-51f6-43a3-bd6e-4033280e47a7-1_all_864.jpg, 0a51dad9-51f6-43a3-bd6e-4033280e47a7-1_all_1086.jpg
- Decorative cake, pen, champagne still-life: a_lavish_highly_detailed_photorealistic_celebrat.png (illustrative artwork)

People were NOT regenerated. Photos were cropped and scaled into matching frames.
The decorative still-life elements are illustrations, not actual merchandise photos.
This poster honors the family of companies as a group; it does not claim all four companies are licensed to provide all services in all states.
